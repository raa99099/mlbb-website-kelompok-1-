<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - MLBB Info</title>
<link rel="stylesheet" href="css/style.css">
<style>
.alert {
    padding: 12px 16px;
    border-radius: 10px;
    margin-bottom: 15px;
    font-size: 14px;
    font-weight: 600;
    text-align: center;
}
.alert-error {
    background: rgba(255, 60, 60, 0.15);
    border: 1px solid rgba(255, 60, 60, 0.4);
    color: #ff6b6b;
}
</style>
</head>
<body class="auth-body">

<div class="particles" id="particles"></div>

<div class="auth-container">

<div class="auth-logo">
    <span class="icon">⚔️</span>
    <h1>MLBB INFO</h1>
    <p>Mobile Legends Bang Bang</p>
</div>

<div class="auth-card">

<div class="auth-topline"></div>

<h2>Buat Akun Baru</h2>

<?php if (!empty($_GET['error'])): ?>
<div class="alert alert-error">
    ❌ <?= htmlspecialchars($_GET['error']) ?>
</div>
<?php endif; ?>

<form method="POST"
      action="../backend/auth/register.php">

<div class="form-group">
<label>Username</label>
<input type="text"
       name="username"
       placeholder="Masukkan Username"
       required>
</div>

<div class="form-group">
<label>Password</label>
<input type="password"
       name="password"
       placeholder="Masukkan Password"
       required>
</div>

<button class="btn-auth">
Daftar
</button>

</form>

<div class="auth-divider">atau</div>

<div class="auth-link-row">
Sudah punya akun?
<a href="login.php">Login</a>
</div>

</div>

</div>

<script src="js/script.js"></script>
<script>initParticles('particles');</script>

</body>
</html>
