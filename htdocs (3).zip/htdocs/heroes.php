<?php
session_start();
include 'backend/config/db.php';

$result = mysqli_query($conn, "SELECT * FROM heroes");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Heroes MLBB</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    color:white;
}

/* NAVBAR */
header{
    background:#111827;
    padding:20px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    font-size:28px;
    font-family:'Cinzel',serif;
    color:#00c8ff;
}

nav a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    transition:.3s;
}

nav a:hover{
    color:#00c8ff;
}

/* BANNER */
.banner{
    text-align:center;
    padding:60px 20px;
    background:linear-gradient(to right,#0f172a,#1e3a8a);
}

.banner h1{
    font-size:50px;
    margin-bottom:10px;
}

.banner p{
    color:#cbd5e1;
}

/* BUTTON */
.top-action{
    width:90%;
    margin:20px auto;
}

.btn{
    display:inline-block;
    padding:10px 18px;
    background:#00c8ff;
    color:white;
    text-decoration:none;
    border-radius:6px;
}

.btn-edit{
    background:orange;
}

.btn-hapus{
    background:red;
}

/* GRID */
.grid{
    width:90%;
    margin:auto;
    padding:40px 0;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:25px;
}

.card{
    background:#1e293b;
    border-radius:15px;
    overflow:hidden;
    border:1px solid rgba(0,200,255,.2);
    transition:.3s;
}

.card:hover{
    transform:translateY(-8px);
    border-color:#00c8ff;
}

.card img{
    width:100%;
    height:300px;
    object-fit:cover;
}

.info{
    padding:20px;
}

.role{
    color:#00c8ff;
    margin:10px 0;
    font-weight:bold;
}

/* FOOTER */
footer{
    text-align:center;
    padding:20px;
    background:#111827;
    margin-top:40px;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<header>

    <div class="logo">⚔️ MLBB INFO</div>

    <nav>
        <a href="index.php">Home</a>
        <a href="heroes.php">Heroes</a>
        <a href="items.php">Items</a>
        <a href="teams.php">Teams</a>

        <?php if(isset($_SESSION['username'])){ ?>
            <a href="logout.php">Logout</a>
        <?php } else { ?>
            <a href="login.php">Login</a>
        <?php } ?>
    </nav>

</header>

<!-- BANNER -->
<section class="banner">
    <h1>Daftar Hero MLBB</h1>
    <p>Pilih hero favoritmu di Land of Dawn</p>
</section>

<!-- BUTTON TAMBAH -->
<div class="top-action">
    <a href="tambah_hero.php" class="btn">+ Tambah Hero</a>
</div>

<!-- GRID HERO -->
<section class="grid">

<?php if(mysqli_num_rows($result) > 0){ ?>

    <?php while($row = mysqli_fetch_assoc($result)){ ?>

    <div class="card">

        <img src="assets/<?php echo $row['image']; ?>" alt="<?php echo $row['nama']; ?>">

        <div class="info">

            <h2><?php echo $row['nama']; ?></h2>

            <p class="role">
                <?php echo $row['role']; ?>
            </p>

            <p>
                <?php echo $row['deskripsi']; ?>
            </p>

            <br>

            <a href="edit_hero.php?id=<?php echo $row['id']; ?>"
               class="btn btn-edit">Edit</a>

            <a href="backend/hero/hapus.php?id=<?php echo $row['id']; ?>"
               class="btn btn-hapus"
               onclick="return confirm('Yakin ingin hapus hero ini?')">
               Hapus
            </a>

        </div>

    </div>

    <?php } ?>

<?php } else { ?>

    <h2 style="text-align:center;">Belum ada data hero</h2>

<?php } ?>

</section>

<!-- FOOTER -->
<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>