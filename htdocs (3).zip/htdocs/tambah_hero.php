
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tambah Hero MLBB</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    color:white;
}

header{
    background:#111827;
    padding:20px 8%;
}

.logo{
    font-size:28px;
    font-family:'Cinzel',serif;
    color:#00c8ff;
}

.container{
    max-width:700px;
    margin:50px auto;
    background:#1e293b;
    padding:30px;
    border-radius:15px;
    border:1px solid rgba(0,200,255,.2);
}

h1{
    text-align:center;
    color:#00c8ff;
    margin-bottom:25px;
}

label{
    display:block;
    margin-bottom:8px;
}

input,
textarea{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    background:#334155;
    color:white;
    margin-bottom:20px;
}

textarea{
    height:120px;
}

.btn{
    display:inline-block;
    padding:10px 20px;
    background:#00c8ff;
    color:white;
    text-decoration:none;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.back{
    background:#475569;
    margin-left:10px;
}

footer{
    text-align:center;
    padding:20px;
    background:#111827;
    margin-top:40px;
}
</style>
</head>

<body>

<header>
    <div class="logo">⚔️ MLBB INFO</div>
</header>

<div class="container">

<h1>Tambah Hero</h1>

<form action="backend/hero/tambah.php" method="POST">

    <label>Nama Hero</label>
    <input type="text" name="nama" required>

    <label>Role</label>
    <input type="text" name="role" required>

    <label>Deskripsi</label>
    <textarea name="deskripsi" required></textarea>

    <label>Nama File Gambar</label>
    <input type="text"
           name="image"
           placeholder="contoh: ling.jpg"
           required>

    <button type="submit" class="btn">
        Simpan Hero
    </button>

    <a href="heroes.php" class="btn back">
        Kembali
    </a>

</form>

</div>

<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>
