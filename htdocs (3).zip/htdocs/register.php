<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MLBB INFO</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background-image: linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1)), url('bacg.jpg');
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    color: white;
}

/* NAVBAR */
.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 8%;
    background:rgba(0,0,0,.4);
    backdrop-filter:blur(10px);
    position:sticky;
    top:0;
}

.logo{
    font-size:28px;
    font-weight:bold;
    color:#00c8ff;
}

.nav-links{
    display:flex;
    list-style:none;
    gap:25px;
}

.nav-links a{
    text-decoration:none;
    color:white;
    transition:.3s;
}

.nav-links a:hover{
    color:#00c8ff;
}

.btn{
    padding:10px 20px;
    background:#00c8ff;
    border-radius:8px;
    text-decoration:none;
    color:white;
}

/* HERO */
.hero{
    min-height:90vh;
    display:flex;
    justify-content:center;
    align-items:center;
    text-align:center;
    padding:50px;
}

.hero h1{
    font-size:70px;
    font-family:'Cinzel',serif;
    color: #E8C44A;
    text-shadow:
    0 0 10px #E8C44A,
    0 0 20px #E8C44A,
    0 0 40px rgba(232,196,74,.5);
}

.hero p{
    max-width:700px;
    margin:20px auto;
    font-size:18px;
}

.hero-buttons{
    margin-top:30px;
}

.hero-buttons a{
    text-decoration:none;
    padding:15px 30px;
    margin:10px;
    border-radius:10px;
    display:inline-block;
}

.primary{
    background:#00c8ff;
    color:white;
}

.secondary{
    border:2px solid #00c8ff;
    color:#00c8ff;
}

/* STATS */
.stats{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
    padding:80px 10%;
}

.stat-box{
    background:rgba(255,255,255,.08);
    padding:30px;
    border-radius:15px;
    text-align:center;
}

.stat-box h2{
    color:#00c8ff;
    font-size:40px;
}

/* SECTION */
.section{
    padding:80px 10%;
}

.section-title{
    text-align:center;
    font-size:40px;
    margin-bottom:40px;
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:25px;
}

.card{
    background:rgba(255,255,255,.08);
    border-radius:15px;
    padding:25px;
    transition:.3s;
}

.card:hover{
    transform:translateY(-10px);
}

.card h3{
    color:#00c8ff;
}

/* FOOTER */
footer{
    text-align:center;
    padding:30px;
    background:black;
}

@media(max-width:768px){
.hero h1{
    font-size:45px;
}
.stats{
    grid-template-columns:1fr;
}
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo">⚔️ MLBB INFO</div>

    <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="heroes.php">Heroes</a></li>
        <li><a href="items.php">Items</a></li>
        <li><a href="teams.php">Teams</a></li>
    </ul>

    <a href="login.php" class="btn">Login</a>
</nav>

<!-- HERO -->
<section class="hero">
    <div>
        <h1>LAND OF DAWN</h1>
        <p>
            Database lengkap Mobile Legends Bang Bang.
            Temukan hero terbaik, item build, tier list,
            dan informasi tim esports profesional.
        </p>

        <div class="hero-buttons">
            <a href="heroes.php" class="primary">Lihat Hero</a>
            <a href="register.php" class="secondary">Daftar</a>
        </div>
    </div>
</section>

<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>