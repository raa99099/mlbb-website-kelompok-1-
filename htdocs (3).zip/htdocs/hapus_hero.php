
<?php
include "../config/db.php";

$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM heroes WHERE id='$id'");

echo "<script>
alert('Hero berhasil dihapus!');
window.location='../../heroes.php';
</script>";
?>

