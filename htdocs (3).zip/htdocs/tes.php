<?php
include 'backend/config/db.php';

if($conn){
    echo "Koneksi berhasil";
}else{
    echo "Koneksi gagal";
}
?>