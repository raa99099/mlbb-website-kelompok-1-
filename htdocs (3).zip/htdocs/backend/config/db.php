<?php

$host = "sql107.infinityfree.com";
$user = "if0_42052642";
$pass = "kelompok1mlbb";
$db   = "if0_42052642_mlbb";

$conn = mysqli_connect($host, $user, $pass, $db);

if(!$conn){
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>