<?php
include "../config/db.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$role = $_POST['role'];
$deskripsi = $_POST['deskripsi'];
$image = $_POST['image'];

mysqli_query($conn,"
UPDATE heroes
SET
nama='$nama',
role='$role',
deskripsi='$deskripsi',
image='$image'
WHERE id='$id'
");

header("Location: ../../heroes.php");
exit;
?>