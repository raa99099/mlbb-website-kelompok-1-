<?php
include "../config/db.php";

$id = $_GET['id'];

if($id){

    mysqli_query($conn, "DELETE FROM heroes WHERE id=$id");

    header("Location: ../../heroes.php");
    exit;

} else {
    echo "ID tidak ditemukan!";
}
?>