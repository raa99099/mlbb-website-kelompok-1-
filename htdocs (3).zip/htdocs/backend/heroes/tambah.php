<?php
include "../config/db.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $nama = $_POST['nama'];
    $role = $_POST['role'];
    $deskripsi = $_POST['deskripsi'];
    $image = $_POST['image'];

    $sql = "INSERT INTO heroes(nama,role,deskripsi,image)
            VALUES('$nama','$role','$deskripsi','$image')";

    if(mysqli_query($conn,$sql)){
        header("Location: ../../heroes.php");
        exit;
    }else{
        echo mysqli_error($conn);
    }

}
?>