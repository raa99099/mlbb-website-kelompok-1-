<?php
include "../config/db.php";

$nama = $_POST['nama'];
$role = $_POST['role'];
$deskripsi = $_POST['deskripsi'];
$image = $_POST['image'];

if($nama && $role && $deskripsi && $image){

    $query = mysqli_query($conn,
        "INSERT INTO heroes (nama, role, deskripsi, image)
         VALUES ('$nama','$role','$deskripsi','$image')"
    );

    if($query){
        header("Location: ../../heroes.php");
        exit;
    } else {
        echo "Gagal insert: " . mysqli_error($conn);
    }

} else {
    echo "Data kosong!";
}
?>