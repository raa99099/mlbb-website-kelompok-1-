<?php
include "../backend/config/db.php";

$query = mysqli_query($conn, "SELECT * FROM heroes");
?>

<table border="1" cellpadding="10">
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>Role</th>
        <th>Deskripsi</th>
        <th>Gambar</th>
        <th>Aksi</th>
    </tr>

    <?php while($hero = mysqli_fetch_assoc($query)) : ?>
    <tr>
        <td><?= $hero['id']; ?></td>
        <td><?= $hero['nama']; ?></td>
        <td><?= $hero['role']; ?></td>
        <td><?= $hero['deskripsi']; ?></td>

        <td>
            <img src="../assets/<?= $hero['image']; ?>"
                 width="100">
        </td>

        <td>
            <a href="edit_hero.php?id=<?= $hero['id']; ?>">
                Edit
            </a>

            |

            <a href="../backend/hero/hapus.php?id=<?= $hero['id']; ?>"
               onclick="return confirm('Yakin ingin menghapus hero ini?')">
                Hapus
            </a>
        </td>
    </tr>
    <?php endwhile; ?>

</table>