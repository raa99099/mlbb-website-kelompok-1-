
<?php
include 'backend/config/db.php';

$id = $_GET['id'];

$query = mysqli_query($conn, "SELECT * FROM heroes WHERE id='$id'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Hero MLBB</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    color:white;
}

header{
    background:#111827;
    padding:20px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    font-size:28px;
    font-family:'Cinzel',serif;
    color:#00c8ff;
}

.container{
    max-width:700px;
    margin:50px auto;
    background:#1e293b;
    padding:30px;
    border-radius:15px;
    border:1px solid rgba(0,200,255,.2);
}

h1{
    text-align:center;
    margin-bottom:25px;
    color:#00c8ff;
}

label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
}

input,
textarea{
    width:100%;
    padding:12px;
    border:none;
    border-radius:8px;
    background:#334155;
    color:white;
    margin-bottom:20px;
}

textarea{
    resize:none;
    height:120px;
}

.btn{
    display:inline-block;
    padding:10px 20px;
    background:#00c8ff;
    color:white;
    text-decoration:none;
    border:none;
    border-radius:8px;
    cursor:pointer;
}

.btn:hover{
    opacity:.9;
}

.back{
    background:#475569;
    margin-left:10px;
}

footer{
    text-align:center;
    padding:20px;
    background:#111827;
    margin-top:40px;
}
</style>
</head>

<body>

<header>
    <div class="logo">⚔️ MLBB INFO</div>
</header>

<div class="container">

<h1>Edit Hero</h1>

<form action="backend/hero/edit.php" method="POST">

    <input type="hidden" name="id"
           value="<?php echo $data['id']; ?>">

    <label>Nama Hero</label>
    <input type="text"
           name="nama"
           value="<?php echo $data['nama']; ?>"
           required>

    <label>Role</label>
    <input type="text"
           name="role"
           value="<?php echo $data['role']; ?>"
           required>

    <label>Deskripsi</label>
    <textarea name="deskripsi" required><?php echo $data['deskripsi']; ?></textarea>

    <label>Nama File Gambar</label>
    <input type="text"
           name="image"
           value="<?php echo $data['image']; ?>"
           placeholder="contoh: ling.jpg"
           required>

    <button type="submit" class="btn">
        Update Hero
    </button>

    <a href="heroes.php" class="btn back">
        Kembali
    </a>

</form>

</div>

<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>
