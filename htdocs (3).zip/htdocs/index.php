<?php
session_start();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MLBB INFO</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background-image:
    linear-gradient(rgba(0,0,0,.4),rgba(0,0,0,.4)),
    url('bacg.jpg');
    background-size:cover;
    background-position:center;
    background-attachment:fixed;
    color:white;
}

.navbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:20px 8%;
    background:rgba(0,0,0,.5);
    backdrop-filter:blur(10px);
    position:sticky;
    top:0;
}

.logo{
    font-size:28px;
    font-weight:bold;
    color:#00c8ff;
}

.nav-links{
    display:flex;
    list-style:none;
    gap:25px;
}

.nav-links a{
    text-decoration:none;
    color:white;
    transition:.3s;
}

.nav-links a:hover{
    color:#00c8ff;
}

.btn{
    padding:10px 20px;
    background:#00c8ff;
    border-radius:8px;
    text-decoration:none;
    color:white;
    font-weight:bold;
}

.user-box{
    display:flex;
    align-items:center;
    gap:15px;
}

.hero{
    min-height:90vh;
    display:flex;
    justify-content:center;
    align-items:center;
    text-align:center;
    padding:50px;
}

.hero h1{
    font-size:70px;
    font-family:'Cinzel',serif;
    color:#E8C44A;
    text-shadow:
        0 0 10px #E8C44A,
        0 0 20px #E8C44A,
        0 0 40px rgba(232,196,74,.5);
}

.hero p{
    max-width:700px;
    margin:20px auto;
    font-size:18px;
}

.hero-buttons{
    margin-top:30px;
}

.hero-buttons a{
    text-decoration:none;
    padding:15px 30px;
    margin:10px;
    border-radius:10px;
    display:inline-block;
}

.primary{
    background:#00c8ff;
    color:white;
}

.secondary{
    border:2px solid #00c8ff;
    color:#00c8ff;
}

footer{
    text-align:center;
    padding:30px;
    background:#000;
}

@media(max-width:768px){

    .navbar{
        flex-direction:column;
        gap:15px;
    }

    .nav-links{
        flex-wrap:wrap;
        justify-content:center;
    }

    .hero h1{
        font-size:45px;
    }
}

</style>
</head>

<body>

<nav class="navbar">

    <div class="logo">⚔️ MLBB INFO</div>

    <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="heroes.php">Heroes</a></li>
        <li><a href="items.php">Items</a></li>
        <li><a href="teams.php">Teams</a></li>
    </ul>

    <div class="user-box">

        <?php if (isset($_SESSION['id'])): ?>

            <span>
                Halo, <b><?php echo $_SESSION['username']; ?></b>
            </span>

            <a href="logout.php" class="btn">
                Logout
            </a>

        <?php else: ?>

            <a href="login.php" class="btn">
                Login
            </a>

        <?php endif; ?>

    </div>

</nav>

<section class="hero">

    <div>

        <h1>LAND OF DAWN</h1>

        <p>
            Database lengkap Mobile Legends Bang Bang.
            Temukan hero terbaik, item build, role hero,
            dan informasi tim esports profesional.
        </p>

        <div class="hero-buttons">

            <a href="heroes.php" class="primary">
                Lihat Hero
            </a>

            <?php if (!isset($_SESSION['id'])): ?>

                <a href="register.php" class="secondary">
                    Daftar
                </a>

            <?php endif; ?>

        </div>

    </div>

</section>

<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>