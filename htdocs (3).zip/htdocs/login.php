<?php
session_start();
include 'backend/config/db.php';

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");

    if(mysqli_num_rows($query) > 0){

        $user = mysqli_fetch_assoc($query);

        if(password_verify($password, $user['password'])){

            $_SESSION['id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            echo "<script>
            alert('Login berhasil!');
            window.location='index.php';
            </script>";

        } else {
            echo "<script>alert('Password salah!');</script>";
        }

    } else {
        echo "<script>alert('Username tidak ditemukan!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login MLBB INFO</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    color:white;
}

.box{
    background:#1e293b;
    padding:40px;
    border-radius:15px;
    width:350px;
    border:1px solid rgba(0,200,255,.2);
}

h2{
    text-align:center;
    margin-bottom:20px;
    color:#00c8ff;
    font-family:'Cinzel',serif;
}

input{
    width:100%;
    padding:12px;
    margin:10px 0;
    border:none;
    border-radius:8px;
    background:#334155;
    color:white;
}

button{
    width:100%;
    padding:12px;
    background:#00c8ff;
    border:none;
    border-radius:8px;
    color:white;
    cursor:pointer;
    font-weight:bold;
}

button:hover{
    opacity:0.9;
}

a{
    color:#00c8ff;
    text-decoration:none;
}
</style>
</head>

<body>

<div class="box">

<h2>Login</h2>

<form method="POST">

    <input type="text" name="username" placeholder="Username" required>

    <input type="password" name="password" placeholder="Password" required>

    <button type="submit" name="login">Login</button>

</form>

<br>

<p style="text-align:center;">
    Belum punya akun? <a href="register.php">Register</a>
</p>

</div>

</body>
</html>