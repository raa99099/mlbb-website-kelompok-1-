<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Items MLBB - MLBB INFO</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    color:white;
}

/* Navbar */
header{
    background:#111827;
    padding:20px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    font-family:'Cinzel',serif;
    font-size:28px;
    color:#00c8ff;
}

nav a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    transition:.3s;
}

nav a:hover{
    color:#00c8ff;
}

/* Banner */
.banner{
    text-align:center;
    padding:80px 20px;
    background:linear-gradient(to right,#0f172a,#1e3a8a);
}

.banner h1{
    font-size:50px;
    margin-bottom:15px;
}

.banner p{
    color:#cbd5e1;
}

/* Items */
.container{
    width:90%;
    margin:auto;
    padding:60px 0;
}

.item-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

.item-card{
    background:#1e293b;
    border-radius:15px;
    padding:25px;
    transition:.3s;
    border:1px solid rgba(0,200,255,.15);
}

.item-card:hover{
    transform:translateY(-10px);
    border-color:#00c8ff;
    box-shadow:0 0 20px rgba(0,200,255,.3);
}

.item-card h3{
    color:#00c8ff;
    margin-bottom:10px;
}

.item-type{
    color:#fbbf24;
    font-weight:bold;
    margin-bottom:10px;
}

.item-desc{
    color:#cbd5e1;
    line-height:1.6;
}

/* Footer */
footer{
    background:#111827;
    text-align:center;
    padding:25px;
    margin-top:50px;
}

/* Mobile */
@media(max-width:768px){

header{
    flex-direction:column;
    gap:15px;
}

.banner h1{
    font-size:36px;
}

}
</style>
</head>

<body>

<header>

<div class="logo">
⚔️ MLBB INFO
</div>

<nav>
<a href="index.html">Home</a>
<a href="heroes.html">Heroes</a>
<a href="items.html">Items</a>
<a href="teams.html">Teams</a>
<a href="login.html">Login</a>
</nav>

</header>

<section class="banner">
<h1>⚙️ Build Item MLBB</h1>
<p>Pilih item terbaik untuk meningkatkan kekuatan hero favoritmu.</p>
</section>

<div class="container">

<div class="item-grid">

<div class="item-card">
<h3>⚔️ Blade of Despair</h3>
<p class="item-type">Physical Attack</p>
<p class="item-desc">
Memberikan Physical Attack terbesar dan sangat efektif untuk hero core.
</p>
</div>

<div class="item-card">
<h3>🗡️ Endless Battle</h3>
<p class="item-type">Physical Attack</p>
<p class="item-desc">
Menambahkan True Damage setelah menggunakan skill.
</p>
</div>

<div class="item-card">
<h3>🔮 Blood Wings</h3>
<p class="item-type">Magic</p>
<p class="item-desc">
Magic Power tinggi dan tambahan shield untuk mage.
</p>
</div>

<div class="item-card">
<h3>✨ Holy Crystal</h3>
<p class="item-type">Magic</p>
<p class="item-desc">
Meningkatkan Magic Damage secara signifikan.
</p>
</div>

<div class="item-card">
<h3>🛡️ Immortality</h3>
<p class="item-type">Defense</p>
<p class="item-desc">
Menghidupkan kembali hero setelah terbunuh.
</p>
</div>

<div class="item-card">
<h3>❄️ Dominance Ice</h3>
<p class="item-type">Defense</p>
<p class="item-desc">
Mengurangi Attack Speed dan HP Regen lawan.
</p>
</div>

<div class="item-card">
<h3>💚 Oracle</h3>
<p class="item-type">Defense</p>
<p class="item-desc">
Meningkatkan efek shield dan regenerasi HP.
</p>
</div>

<div class="item-card">
<h3>🔥 Divine Glaive</h3>
<p class="item-type">Magic</p>
<p class="item-desc">
Memberikan Magic Penetration tinggi terhadap tank.
</p>
</div>

</div>

</div>


</body>
</html>