<?php
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Teams MLBB</title>

<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Exo+2:wght@300;400;600&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Exo 2',sans-serif;
}

body{
    background:#0f172a;
    color:white;
}

/* NAVBAR */
header{
    background:#111827;
    padding:20px 8%;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    font-size:28px;
    font-family:'Cinzel',serif;
    color:#00c8ff;
}

nav a{
    color:white;
    text-decoration:none;
    margin-left:20px;
    transition:.3s;
}

nav a:hover{
    color:#00c8ff;
}

/* BANNER */
.banner{
    text-align:center;
    padding:80px 20px;
    background:linear-gradient(to right,#0f172a,#1e3a8a);
}

.banner h1{
    font-size:50px;
    margin-bottom:10px;
    font-family:'Cinzel',serif;
}

.banner p{
    color:#cbd5e1;
}

/* GRID */
.container{
    width:90%;
    margin:auto;
    padding:50px 0;
}

.team-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:25px;
}

/* CARD */
.team-card{
    background:#1e293b;
    padding:25px;
    border-radius:15px;
    border:1px solid rgba(0,200,255,.2);
    transition:.3s;
}

.team-card:hover{
    transform:translateY(-8px);
    border-color:#00c8ff;
}

.team-card h3{
    color:#00c8ff;
    margin-bottom:10px;
    font-size:20px;
}

.team-card p{
    margin-bottom:8px;
    color:#cbd5e1;
}

/* FOOTER */
footer{
    text-align:center;
    padding:20px;
    background:#111827;
    margin-top:40px;
}

@media(max-width:768px){
    .banner h1{
        font-size:36px;
    }
}
</style>

</head>

<body>

<!-- NAVBAR -->
<header>

    <div class="logo">⚔️ MLBB INFO</div>

    <nav>
        <a href="index.php">Home</a>
        <a href="heroes.php">Heroes</a>
        <a href="items.php">Items</a>
        <a href="teams.php">Teams</a>
    </nav>

</header>

<!-- BANNER -->
<section class="banner">
    <h1>Tim Esports MLBB</h1>
    <p>Daftar tim Mobile Legends profesional terbaik</p>
</section>

<!-- CONTENT -->
<div class="container">

    <div class="team-grid">

        <div class="team-card">
            <h3>ONIC Esports</h3>
            <p>Negara: Indonesia</p>
            <p>Juara MPL Indonesia dan salah satu tim terkuat.</p>
        </div>

        <div class="team-card">
            <h3>EVOS Glory</h3>
            <p>Negara: Indonesia</p>
            <p>Juara Dunia M1 World Championship.</p>
        </div>

        <div class="team-card">
            <h3>Team Liquid PH</h3>
            <p>Negara: Filipina</p>
            <p>Tim kuat MPL Philippines.</p>
        </div>

        <div class="team-card">
            <h3>Falcon Esports</h3>
            <p>Negara: Myanmar</p>
            <p>Tim kuat Asia Tenggara.</p>
        </div>

        <div class="team-card">
            <h3>Alter Ego</h3>
            <p>Negara: Indonesia</p>
            <p>Salah satu tim esports unggulan Indonesia.</p>
        </div>

    </div>

</div>

<!-- FOOTER -->
<footer>
    <p>© 2026 MLBB INFO</p>
</footer>

</body>
</html>